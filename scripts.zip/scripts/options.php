<?php

    $options['appName'] = 'BubblePopRabbit.x86_64';
